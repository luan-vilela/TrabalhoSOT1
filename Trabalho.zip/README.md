
# Trabalho SO T1

 - Para compilar rode.

	    terminal:
	    gcc *.c -o main -lpthread 
 
 - Executar
 
		 terminal:
		./main

 - Executar com entrar do .txt

		 terminal:
		./main < entradas.txt 
